const fs = require('fs');
const path = require('path');

const LB_FILE = path.join(__dirname, '..', 'data', 'leaderboard.json');
const POINTS = { n5: 10, n4: 20, n3: 30, n2: 40, n1: 50 };

function getWeekNumber(d) {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
    var yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
    var weekNo = Math.ceil(( ( (d - yearStart) / 86400000) + 1)/7);
    return d.getUTCFullYear() + '-W' + weekNo;
}

function loadLB() {
  if (!fs.existsSync(LB_FILE)) return { daily: {}, weekly: {} };
  try {
    return JSON.parse(fs.readFileSync(LB_FILE, 'utf-8'));
  } catch(e) {
    return { daily: {}, weekly: {} };
  }
}

function saveLB(data) {
  fs.writeFileSync(LB_FILE, JSON.stringify(data, null, 2));
}

function updateLeaderboard(winner, finalPlayers, level) {
  const data = loadLB();
  // Waktu Bangkok (Asia/Jakarta)
  const now = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Bangkok"}));
  const today = now.toISOString().split('T')[0];
  const thisWeek = getWeekNumber(now);

  if (data.daily?.date !== today) {
    data.daily = { date: today, scores: {} };
  }
  if (data.weekly?.week !== thisWeek) {
    data.weekly = { week: thisWeek, scores: {} };
  }

  const pts = POINTS[level] || 10;
  // Jangan masukkan skor untuk bot
  const winners = finalPlayers.filter(p => p.team === winner && !p.isBot);

  winners.forEach(p => {
    data.daily.scores[p.name] = (data.daily.scores[p.name] || 0) + pts;
    data.weekly.scores[p.name] = (data.weekly.scores[p.name] || 0) + pts;
  });

  saveLB(data);
}

function getLeaderboard() {
  const data = loadLB();
  const sortScores = (scoresObj) => {
    return Object.entries(scoresObj || {})
      .map(([name, score]) => ({ name, score }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  };
  
  return {
    daily: sortScores(data.daily?.scores),
    weekly: sortScores(data.weekly?.scores)
  };
}

module.exports = { updateLeaderboard, getLeaderboard };
